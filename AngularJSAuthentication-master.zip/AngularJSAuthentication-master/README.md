AngularJS Authentication
=======================

Tutorial shows Authentication in AngularJS with ASP.NET Web API 2 and Owin Middleware using access tokens and refresh tokens approach. 

![Alt text](http://bitoftech.net/wp-content/uploads/2014/05/AngularJSAuthentication.png "AngularJS Authentication")
![Alt text](http://bitoftech.net/wp-content/uploads/2014/07/RefreshTokenAngularJS.jpg "AngularJS Refresh Tokens")
